package visao;

import dominio.Tabela;

public class Principal {

	public static void main(String[] args) {
		new Tabela().setVisible(true);

	}

}
