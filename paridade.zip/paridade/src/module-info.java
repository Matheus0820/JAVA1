/**
 * 
 */
/**
 * @author Aluno
 *
 */
module paridade {
}